# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import copy
import unittest

from reconcile_pro_cache import reconcile


def receipt():
    groups, tensors = [], []
    for index, (block, window, count) in enumerate(
        [(64, 128, 32), (64, 128, 32), (256, None, 91), (8, 128, 31), (4, 8, 60)]
    ):
        members = {
            f"g{index}.layer{layer}": {
                "type": "MLAAttentionSpec" if window is None else "SlidingWindowMLASpec",
                "block_size": block,
                "sliding_window": window,
                "page_size_bytes": 1,
            }
            for layer in range(count)
        }
        groups.append(
            {"host_resident": False, "layer_names": list(members), "kv_cache_spec": {"kv_cache_specs": members}}
        )
        tensors.append(
            {
                "block_stride": 1025,
                "size": 10250000,
                "host_resident": False,
                "offset": 0,
                "layer_stride": 1,
                "layers": list(members),
            }
        )
    config = {
        "kv_cache_groups": groups,
        "kv_cache_tensors": tensors,
        "kv_cache_layout": "BLHNC",
        "kv_tp_replicas": 8,
        "hisparse_host_num_blocks": None,
        "num_blocks": 10000,
    }
    return {
        "results": [
            {"rank": rank, "kv_cache_config": copy.deepcopy(config), "available_kv_cache_memory_bytes": 10250000}
            for rank in range(8)
        ]
    }


def run(value, concurrency=1, input_length=1024):
    return reconcile(value, k=6, concurrency=concurrency, input_length=input_length, output_length=1024)


class CacheReceiptTests(unittest.TestCase):
    def test_aliases_are_not_summed_and_pool_blocks_are_preserved(self):
        result = run(receipt())
        self.assertEqual(result["physical_pool_bytes_per_rank"], 10250000)
        self.assertEqual(result["replay_kv_cache"]["capacity"]["blocks"], 10000)
        self.assertEqual(result["approximate_steady_state_blocks_per_request"], 31)
        self.assertEqual(result["representation_rounding_bytes_per_block"], 255)
        self.assertTrue(result["capacity_proven_nonbinding"])

    def test_transient_bound_includes_async_final_rounds_and_draft_lookahead(self):
        result = run(receipt())
        # Two PP1 in-flight rounds each retain all K+1 query positions, even
        # when the requested output would end partway through the round.
        self.assertEqual(result["conservative_retained_tokens_per_group"], 1024 + 1024 + 2 * 7 + 6)
        self.assertEqual(result["max_concurrent_batches_bound"], 2)
        self.assertEqual(result["conservative_peak_blocks"], 857)

    def test_incomplete_or_inconsistent_ranks_are_rejected(self):
        value = receipt()
        value["results"].pop()
        with self.assertRaisesRegex(ValueError, "eight unique"):
            run(value)
        value = receipt()
        value["results"][1]["kv_cache_config"]["num_blocks"] -= 1
        with self.assertRaisesRegex(ValueError, "configurations differ"):
            run(value)

    def test_missing_physical_layer_and_overflow_are_rejected(self):
        for overflow in (False, True):
            value = receipt()
            for rank in value["results"]:
                tensor = rank["kv_cache_config"]["kv_cache_tensors"][0]
                if overflow:
                    tensor["offset"] = 1025
                else:
                    tensor["layers"].pop()
            with self.assertRaises(ValueError):
                run(value)

    def test_larger_workload_cannot_inherit_small_run_capacity_qualification(self):
        result = run(receipt(), concurrency=64, input_length=8192)
        self.assertFalse(result["capacity_proven_nonbinding"])


if __name__ == "__main__":
    unittest.main()
