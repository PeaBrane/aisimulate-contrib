# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Launch an aggregated DSpark smoke, acceptance pilot, or initial fixed cells."""

import argparse
import hashlib
import json
import math
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
from pathlib import Path

from campaign import IMAGE, MODELS, RUNTIME_REVISION
from collect_fixed import fetch
from inspect_runtime import checkpoint_path, inspect_checkpoint
from window_plan import add_selection_arguments, execute_runs, select_runs


def server_command(
    model_key,
    k,
    port,
    role="agg",
    synthetic_al=None,
    graph_policy="eager",
    prefix_cache=False,
    load_strategy=None,
    startup_timeout_s=3600,
    context_length=16384,
    gpu_memory_utilization=0.90,
    max_batched_tokens=8192,
):
    if type(max_batched_tokens) is not int or max_batched_tokens <= 0:
        raise ValueError("maximum batched tokens must be positive")
    if type(context_length) is not int or context_length <= 0:
        raise ValueError("context length must be positive")
    if not math.isfinite(gpu_memory_utilization) or not 0 < gpu_memory_utilization <= 1:
        raise ValueError("GPU memory utilization must be within (0, 1]")
    model = MODELS[model_key]
    checkpoint = inspect_checkpoint(model["model"], model["revision"])
    speculation = {
        "method": "dspark",
        "num_speculative_tokens": k,
        "enable_adaptive_verification": False,
        "draft_sample_method": "probabilistic",
        "rejection_sample_method": "block",
    }
    if synthetic_al is not None:
        if not 1 <= synthetic_al <= k + 1:
            raise ValueError("synthetic AL must include bonus and be within [1, K+1]")
        speculation["rejection_sample_method"] = "synthetic"
        speculation["synthetic_acceptance_length"] = synthetic_al
    if "draft_model" in model:
        speculation["model"] = str(checkpoint_path(model["draft_model"], model["draft_revision"]))
        speculation["attention_backend"] = "FLASHINFER_MLA"
    command = [
        sys.executable,
        "-m",
        "vllm.entrypoints.openai.api_server",
        "--model",
        checkpoint["path"],
        "--served-model-name",
        model["model"],
        "--tensor-parallel-size",
        str(model["gpus_per_role"]),
        "--trust-remote-code",
        "--language-model-only",
        "--kv-cache-dtype",
        "fp8",
        "--gpu-memory-utilization",
        str(gpu_memory_utilization),
        "--max-model-len",
        str(context_length),
        "--max-num-seqs",
        "64",
        "--max-num-batched-tokens",
        str(max_batched_tokens),
        "--enable-prefix-caching" if prefix_cache else "--no-enable-prefix-caching",
        "--port",
        str(port),
        "--seed",
        "42",
        "--speculative-config",
        json.dumps(speculation),
    ]
    if load_strategy is not None:
        command += ["--safetensors-load-strategy", load_strategy]
    if graph_policy == "eager":
        command.append("--enforce-eager")
    if model_key == "v4-pro":
        command += ["--attention-backend", "FLASHMLA_SPARSE_DSV4"]
    if model_key == "kimi-k3":
        command += [
            "--attention-backend",
            "FLASHINFER_MLA",
            "--attention-config",
            '{"use_prefill_query_quantization":true,"mla_prefill_backend":"TRTLLM_RAGGED"}',
        ]
    if model_key == "v41-flash":
        command += [
            "--tokenizer-mode",
            "deepseek_v41",
            "--engram-config",
            '{"cpu_offload":false}',
        ]
    env = {
        **os.environ,
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
        "VLLM_USE_V2_MODEL_RUNNER": "1",
        "VLLM_USE_RUST_FRONTEND": "0",
        "VLLM_ENGINE_READY_TIMEOUT_S": str(startup_timeout_s),
    }
    if role == "agg":
        command += [
            "--host",
            "127.0.0.1",
            "--worker-extension-cls",
            "runtime_receipt.DsparkReceiptWorker",
        ]
        env["VLLM_SERVER_DEV_MODE"] = "1"
    if role != "agg":
        private_host = env.get("VLLM_NIXL_SIDE_CHANNEL_HOST")
        if not private_host or private_host in ("0.0.0.0", "::"):
            raise ValueError("P/D receipt RPC requires an explicit private role host")
        command += [
            "--host",
            private_host,
            "--worker-extension-cls",
            "runtime_receipt.DsparkReceiptWorker",
        ]
        env["VLLM_SERVER_DEV_MODE"] = "1"
        command += [
            "--kv-transfer-config",
            json.dumps({"kv_connector": "NixlConnector", "kv_role": "kv_both"}),
        ]
        if role == "prefill" and model_key == "v4-pro":
            command[command.index("--tensor-parallel-size") + 1] = "1"
            command += ["--data-parallel-size", "8", "--enable-expert-parallel"]
    return command, env, checkpoint


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model-key", choices=list(MODELS), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--port", type=int, default=8010)
    parser.add_argument("--context-length", type=int, default=16384)
    parser.add_argument("--prefix-cache", action="store_true")
    parser.add_argument("--mode", choices=["smoke", "pilot", "initial", "sweep"], default="smoke")
    parser.add_argument("--graph-policy", choices=["eager", "runtime-default"], default="eager")
    parser.add_argument("--load-strategy", choices=["eager"])
    parser.add_argument("--startup-timeout", type=int, default=3600)
    parser.add_argument("--concurrency", type=int, choices=[1, 4, 8, 16, 64], action="append")
    parser.add_argument("--repetition", type=int, choices=[1, 2, 3], action="append")
    add_selection_arguments(parser)
    acceptance = parser.add_mutually_exclusive_group()
    acceptance.add_argument("--synthetic-al", type=float)
    acceptance.add_argument("--synthetic-control", type=Path)
    args = parser.parse_args()
    if args.startup_timeout <= 0:
        parser.error("startup timeout must be positive and fit the Slurm allocation with cleanup margin")
    model = MODELS[args.model_key]
    if args.k not in model["k"]:
        parser.error("K must be in the approved matrix")
    control = None
    if args.synthetic_control is not None:
        control = json.loads(args.synthetic_control.read_text())
        accepted = control["accepted_tokens"]
        if (
            control.get("model_key") != args.model_key
            or control.get("model_revision") != model["revision"]
            or control.get("k") != args.k
            or control.get("frozen_before_measurement") is not True
            or not math.isfinite(accepted)
            or not 0 <= accepted <= args.k
        ):
            parser.error("frozen control identity or accepted mean does not match model/K")
        args.synthetic_al = 1 + accepted
    if (
        control is None
        and args.synthetic_al is not None
        and (args.k != model["reference_k"] or args.synthetic_al != model["reference_al"])
    ):
        parser.error("non-reference synthetic AL needs a separately frozen pilot control")
    if args.mode == "pilot" and args.synthetic_al is not None:
        parser.error("pilots must measure real acceptance")
    if args.mode == "sweep" and args.prefix_cache:
        parser.error("fixed-length sweep requires prefix caching disabled")
    acceptance_kind = "synthetic" if args.synthetic_al is not None else "real"
    plan = select_runs(args, "agg", acceptance_kind)
    if args.selection_only:
        print(json.dumps(plan, indent=2))
        return
    if not plan:
        raise ValueError("no uncompleted windows selected; skip this server launch")
    args.output.mkdir(parents=True, exist_ok=False)
    if args.completed_runs:
        shutil.copy2(args.completed_runs, args.output / "completed-runs.json")
    source_dir = args.output / "source"
    source_dir.mkdir()
    source_hashes = {}
    for name in (
        "serve_smoke.py",
        "window_plan.py",
        "campaign.py",
        "collect_fixed.py",
        "acceptance.py",
        "runtime_receipt.py",
        "inspect_runtime.py",
        "matrix.json",
    ):
        source = Path(__file__).with_name(name)
        shutil.copy2(source, source_dir / name)
        source_hashes[name] = hashlib.sha256(source.read_bytes()).hexdigest()
    command, env, checkpoint = server_command(
        args.model_key,
        args.k,
        args.port,
        synthetic_al=args.synthetic_al,
        graph_policy=args.graph_policy,
        prefix_cache=args.prefix_cache,
        context_length=args.context_length,
        load_strategy=args.load_strategy,
        startup_timeout_s=args.startup_timeout,
    )
    env["PYTHONPATH"] = str(source_dir.resolve()) + os.pathsep + env.get("PYTHONPATH", "")
    identity = {
        "model": model,
        "checkpoint": checkpoint,
        "image": IMAGE,
        "runtime_revision": RUNTIME_REVISION,
        "server_command": command,
        "launcher_source_sha256": source_hashes["serve_smoke.py"],
        "source_hashes": source_hashes,
        "runtime_environment": {
            name: env[name]
            for name in (
                "OMP_NUM_THREADS",
                "MKL_NUM_THREADS",
                "VLLM_USE_V2_MODEL_RUNNER",
                "VLLM_USE_RUST_FRONTEND",
                "VLLM_SERVER_DEV_MODE",
                "VLLM_ENGINE_READY_TIMEOUT_S",
            )
        },
        "graph_policy": args.graph_policy,
        "weight_load_strategy": args.load_strategy or "runtime-default",
        "startup_timeout_s": args.startup_timeout,
        "prefix_cache": args.prefix_cache,
        "external_kv_offload": False,
        "engram_cpu_offload": False,
        "phase": args.mode,
        "window_selection": [{"cell_id": r["cell"]["cell_id"], "repetition": r["repetition"]} for r in plan],
        "completed_runs_sha256": hashlib.sha256(args.completed_runs.read_bytes()).hexdigest()
        if args.completed_runs
        else None,
        "qualification": {
            "eligible": False,
            "reasons": ["effective cache and runtime qualification pending"],
        },
    }
    if control is not None:
        identity["synthetic_control"] = control
    elif args.synthetic_al is not None:
        if args.k != model["reference_k"] or args.synthetic_al != model["reference_al"]:
            parser.error("non-reference synthetic AL needs a separately frozen pilot control")
        identity["synthetic_control"] = {
            "accepted_tokens": args.synthetic_al - 1,
            "synthetic_acceptance_length": args.synthetic_al,
            "frozen_before_measurement": True,
            "source": f"AgentX result {model['reference_result']}",
            "producer": f"vllm/config/speculative.py::_acceptance_length_to_rates@{RUNTIME_REVISION}",
        }
    identity_path = args.output / "identity.json"
    identity_path.write_text(json.dumps(identity, indent=2) + "\n")
    subprocess.run(
        [
            "nvidia-smi",
            "--query-gpu=name,uuid,memory.total,driver_version,power.limit,clocks.sm",
            "--format=csv",
        ],
        stdout=(args.output / "gpu.csv").open("w"),
        check=True,
    )
    status = {"status": "starting", "model_key": args.model_key, "k": args.k}
    with (args.output / "server.log").open("w") as log:
        process = subprocess.Popen(
            command,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            deadline = time.monotonic() + args.startup_timeout
            while True:
                if process.poll() is not None:
                    raise RuntimeError(f"server exited {process.returncode}")
                if time.monotonic() > deadline:
                    raise TimeoutError(f"server startup exceeded {args.startup_timeout} seconds")
                try:
                    with fetch(f"http://127.0.0.1:{args.port}/health", timeout=5):
                        break
                except (urllib.error.URLError, TimeoutError):
                    time.sleep(10)
            with fetch(
                f"http://127.0.0.1:{args.port}/collective_rpc",
                {"method": "dspark_campaign_receipt", "timeout": 120},
                timeout=150,
            ) as response:
                cache_receipt = json.load(response)
            ranks = cache_receipt["results"]
            if len(ranks) != model["gpus_per_role"] or {r["rank"] for r in ranks} != set(range(model["gpus_per_role"])):
                raise ValueError("runtime cache receipt is missing TP ranks")
            cache_path = args.output / "effective-cache.json"
            cache_bytes = (json.dumps(cache_receipt, indent=2, sort_keys=True) + "\n").encode()
            cache_path.write_bytes(cache_bytes)
            identity["runtime_cache_sha256"] = hashlib.sha256(cache_bytes).hexdigest()
            identity["cache_receipt_extension_sha256"] = hashlib.sha256(
                (source_dir / "runtime_receipt.py").read_bytes()
            ).hexdigest()
            identity_path.write_text(json.dumps(identity, indent=2) + "\n")
            acceptance = "synthetic" if args.synthetic_al is not None else "real"
            ready = {
                "identity_path": str(identity_path),
                "effective_config_path": str(cache_path),
                "log_paths": [str(args.output / "server.log")],
                "cache_capacity_by_role_rank": {"agg": ranks},
                "model_config_paths": [str(Path(checkpoint["path"]) / "config.json")],
                "cell_id": f"{args.model_key}-agg-k{args.k}-i1024-o1024-c1-{acceptance}",
                "endpoint": f"http://127.0.0.1:{args.port}",
                "metrics_urls": [f"http://127.0.0.1:{args.port}/metrics"],
                "qualification_note": (
                    "resolved cache capacity and actual attention geometry must be read from server log before pairing"
                ),
            }
            (args.output / "server-ready.json").write_text(json.dumps(ready, indent=2) + "\n")
            execute_runs(
                plan,
                mode=args.mode,
                output=args.output,
                source_dir=source_dir,
                model_key=args.model_key,
                k=args.k,
                identity_path=identity_path,
                endpoint=ready["endpoint"],
                metrics_urls=ready["metrics_urls"],
            )
            status["status"] = "success"
        except Exception as error:
            status.update(status="failed", error=f"{type(error).__name__}: {error}")
            raise
        finally:
            (args.output / "status.json").write_text(json.dumps(status, indent=2) + "\n")
            os.killpg(process.pid, signal.SIGTERM) if process.poll() is None else None
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()


if __name__ == "__main__":
    main()
