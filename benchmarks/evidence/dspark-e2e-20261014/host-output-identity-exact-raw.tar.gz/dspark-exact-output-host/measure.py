"""Original exact-token CPU stress fixture; not AgentX serving evidence."""

import copy
import hashlib
import json
import os
import platform
import re
import statistics
import subprocess
import time
from pathlib import Path

import yaml


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    out = Path('/tmp/dspark-exact-output-host')
    out.mkdir(exist_ok=True)
    roots = {'base': Path('/tmp/aisim-dspark-pd-pair-b1c56e9c'), 'head': Path('/tmp/aisim-dspark-host-5bf8f6e8')}
    header = {'schema': 'dynamo.agentic_mooncake', 'version': 2, 'block_size': 64,
              'hash_id_scope': 'local', 'source': {'format': 'original-cpu-stress', 'digest': 'exact-output-identity-v1'}}
    rows = [header]
    for play in range(8):
        for turn in range(32):
            rows.append({'request_id': f'p{play}-t{turn}', 'play_id': f'p{play}',
                         'session_id': f's{play}', 'model': 'original-cpu-fixture',
                         'input_length': 1024 + 128 * turn,
                         'input_token_ids': [play + 1] + list(range(100, 1123 + 128 * turn)),
                         'output_length': 128, 'not_before_ms': 0,
                         'recorded_api_time_ms': 10,
                         'wait_for': [] if turn == 0 else [f'p{play}-t{turn - 1}'],
                         'tool_wait_ms': 2})
    trace = out / 'exact-agentic.jsonl'
    trace.write_text(''.join(json.dumps(row) + '\n' for row in rows))
    shared = json.loads(Path('/tmp/dspark-output-policy-host/host-results.json').read_text())
    result = {'scope': __doc__, 'platform': platform.platform(), 'threads': 1,
              'build_profile': 'release', 'identities': shared['identities'],
              'script_sha256': digest(Path(__file__)), 'trace_sha256': digest(trace),
              'expected': {'requests': 256, 'output_tokens': 32768}, 'runs': []}
    env = {**os.environ, **dict.fromkeys(['RAYON_NUM_THREADS', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'], '1')}
    for name in ['agentx', 'agentx-dspark']:
        config = yaml.safe_load(Path(f'/tmp/dspark-output-policy-host/{name}.yaml').read_text())
        config['traffic']['source'] = {'type': 'trace', 'format': 'agentic_mooncake', 'paths': [str(trace)]}
        config['engine']['workers']['aggregated']['parallelism']['replicas'] = 1
        path = out / f'{name}.yaml'
        path.write_text(yaml.safe_dump(config))
        result.setdefault('config_sha256', {})[name] = digest(path)
        for repeat in range(-1, 5):
            for label, root in roots.items():
                target = out / f'{name}-{label}-{repeat}'
                command = ['/usr/bin/time', '-l', str(root / 'python/aisimulate/.venv/bin/aisimulate'),
                           'predict', '--stack', 'engine', '-c', str(path), '--output-dir', str(target), '--format', 'json']
                start = time.perf_counter()
                run = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=600)
                elapsed = time.perf_counter() - start
                target.mkdir(exist_ok=True)
                (target / 'stdout.log').write_text(run.stdout)
                (target / 'stderr.log').write_text(run.stderr)
                if run.returncode:
                    raise RuntimeError(run.stderr[-3000:])
                report = json.loads(run.stdout)
                metrics = report.get('metrics', report.get('summary', report))
                assert (metrics['completed_requests'], metrics['total_output_tokens']) == (256, 32768)
                rss = re.search(r'(\d+)\s+maximum resident set size', run.stderr)
                row = {'case': name, 'build': label, 'repeat': repeat, 'wall_seconds': elapsed,
                       'completed_requests': 256, 'total_output_tokens': 32768,
                       'peak_rss_bytes': int(rss[1]) if rss else None}
                result['runs'].append(row)
                print(json.dumps(row), flush=True)
                (out / 'host-results.json').write_text(json.dumps(result, indent=2) + '\n')
    result['medians_seconds'] = {f'{case}/{label}': statistics.median(
        r['wall_seconds'] for r in result['runs'] if r['case'] == case and r['build'] == label and r['repeat'] >= 0)
        for case in ['agentx', 'agentx-dspark'] for label in roots}
    (out / 'host-results.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    main()
