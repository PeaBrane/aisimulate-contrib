#!/usr/bin/env bash
set -euo pipefail
: "${storage_root:?}"
export PYTHONPATH=/workspace/jobs/dspark-e2e-20261014/v41-native-current-bundle
export HF_HUB_OFFLINE=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
srun --nodes=1 --ntasks=1 --gres=gpu:0 --cpus-per-task=2 --mem=8G \
 --container-image="$storage_root/images/vllm-ac9126e58aa7-3d17635c.sqsh" \
 --container-mounts="$storage_root:/workspace,/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model:/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model:ro" \
 --container-workdir=/workspace/jobs/dspark-e2e-20261014/v41-native-current-bundle \
 --container-env=PYTHONPATH,HF_HUB_OFFLINE,OMP_NUM_THREADS,MKL_NUM_THREADS \
 python3 - <<'PY'
import hashlib,importlib,json,random,subprocess,sys
from pathlib import Path
import vllm
from vllm.tokenizers import get_tokenizer
from collector.vllm.dsv41_native_observer import Dsv41ObserverWorker
root=Path(vllm.__file__).parent
bundle=Path.cwd()
source=json.loads((bundle/'collector/vllm/dsv41_native_sources.json').read_text())
for module,expected in source.items():
 p=root.joinpath(*module.split('.')[1:]).with_suffix('.py')
 actual=hashlib.sha256(p.read_bytes()).hexdigest(); print(module,actual,'MATCH' if actual==expected else 'MISMATCH',flush=True);assert actual==expected
model=Path('/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model/deepseek-ai_deepseek-v4.1-flash/hf/hf-5254448103b6254fc646dacbca1cbbf20e9216c1_orig')
tok=get_tokenizer(str(model),tokenizer_mode='deepseek_v41',trust_remote_code=True)
text=' '.join(f'Experiment {i}: compare the measured time of the system and explain the result clearly.' for i in range(128))
tokens=tok.encode(text,add_special_tokens=False);tokens=tokens*((1024+len(tokens))//len(tokens)+1)
start=random.Random(43).randint(0,len(tokens)-1024);tokens=tokens[start:start+1024];assert len(tokens)==1024
out=Path('/workspace/results/dspark-e2e-20261014/v41-native-preflight');out.mkdir(exist_ok=True)
(out/'prompt-token-ids.json').write_text(json.dumps(tokens)+'\n')
subprocess.run([sys.executable,'-m','collector.vllm.collect_dsv41_native','--help'],check=True)
exports={}
for relative in ['v1/kv_cache_interface.py','v1/core/kv_cache_utils.py']:
 p=root/relative;dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());exports[relative]=hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'status':'passed','scope':'CPU source hash/worker import/tokenizer/CLI; no GPU execution','source_sha256':source,'exported_source_sha256':exports,'prompt_length':len(tokens),'tokenizer_mode':'deepseek_v41','prompt_sha256':hashlib.sha256((out/'prompt-token-ids.json').read_bytes()).hexdigest(),'bundle_sha256':{str(p.relative_to(bundle)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (bundle/'collector/vllm').glob('*') if p.is_file()}}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
PY
