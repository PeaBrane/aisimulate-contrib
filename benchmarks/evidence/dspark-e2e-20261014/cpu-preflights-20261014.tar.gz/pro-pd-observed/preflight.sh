#!/usr/bin/env bash
set -euo pipefail
: "${storage_root:?}"
export PYTHONPATH=/workspace/jobs/dspark-e2e-20261014/pro-pd-observed-bundle
srun --nodes=1 --ntasks=1 --gres=gpu:0 --cpus-per-task=2 --mem=8G --container-image="$storage_root/images/vllm-ac9126e58aa7-3d17635c.sqsh" --container-mounts="$storage_root:/workspace,/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model:/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model:ro" --container-env=PYTHONPATH python3 - <<'PY'
import hashlib,json,os,subprocess,sys
from pathlib import Path
from source_pool_observer import SourcePoolObserverScheduler,verify_sources
from vllm.v1.core.sched.async_scheduler import AsyncScheduler
from vllm.config.scheduler import SchedulerConfig
hashes=verify_sources();assert issubclass(SourcePoolObserverScheduler,AsyncScheduler)
for name in ['schedule','_update_after_schedule','_update_request_with_output']:
 assert getattr(SourcePoolObserverScheduler,name) is getattr(AsyncScheduler,name),name
cfg=SchedulerConfig(max_model_len=16384,is_encoder_decoder=False,scheduler_cls='source_pool_observer.SourcePoolObserverScheduler',async_scheduling=True)
assert cfg.get_scheduler_cls() is SourcePoolObserverScheduler
bundle=Path('/workspace/jobs/dspark-e2e-20261014/pro-pd-observed-bundle')
out=Path('/workspace/results/dspark-e2e-20261014/pro-pd-observed-preflight');out.mkdir(exist_ok=True)
for role,port,budget in [('prefill','8010','0.92'),('decode','8020','0.90')]:
 env=dict(os.environ,VLLM_NIXL_SIDE_CHANNEL_HOST=f'cpu-check-{role}',VLLM_NIXL_SIDE_CHANNEL_PORT='5557')
 subprocess.run([sys.executable,str(bundle/'serve_role.py'),'--model-key','v4-pro','--role',role,'--k','6','--port',port,'--output',str(out),'--graph-policy','runtime-default','--gpu-memory-utilization',budget,'--observe-source-pool','--preflight-only'],env=env,check=True)
 row=json.loads((out/f'{role}-preflight.json').read_text())
 assert row['source_pool_observer']['enabled']
 assert row['runtime_environment']['AISIM_POOL_OBSERVER_ROLE']==role
 assert '--scheduler-cls' in row['command']
receipt={'status':'passed','scope':'CPU source/import/subclass/unchanged inherited scheduling methods and scheduler class resolution; no GPU execution','source_sha256':hashes,'bundle_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in bundle.glob('*') if p.is_file()}}
Path('/workspace/results/dspark-e2e-20261014/pro-pd-observed-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
PY
