#!/usr/bin/env bash
set -euo pipefail
: "${storage_root:?}"
export PYTHONPATH=/workspace/jobs/dspark-e2e-20261014/kimi-ragged-native-bundle
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
srun --nodes=1 --ntasks=1 --gres=gpu:0 --cpus-per-task=2 --mem=8G \
 --container-image="$storage_root/images/vllm-ac9126e58aa7-3d17635c.sqsh" \
 --container-mounts="$storage_root:/workspace" \
 --container-workdir=/workspace/jobs/dspark-e2e-20261014/kimi-ragged-native-bundle \
 --container-env=PYTHONPATH,OMP_NUM_THREADS,MKL_NUM_THREADS python3 - <<'PY'
import ast,hashlib,json,subprocess,sys
from types import SimpleNamespace
from collector.vllm.kimi_native_contract import PREFILL_BACKEND
from pathlib import Path
import vllm
from collector.vllm.kimi_native_observer import KimiObserverWorker
root=Path(vllm.__file__).parent;bundle=Path.cwd()
manifest=json.loads((bundle/'collector/vllm/kimi_native_sources.json').read_text())
for module,expected in manifest.items():
 p=root.joinpath(*module.split('.')[1:]).with_suffix('.py');actual=hashlib.sha256(p.read_bytes()).hexdigest(); print(module,actual,'MATCH' if actual==expected else 'MISMATCH',flush=True);assert actual==expected
src=(bundle/'collector/vllm/collect_kimi_native.py').read_text()
tree=ast.parse(src)
node=next(n for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='engine_args' for t in n.targets))
args=SimpleNamespace(model=Path('/model'),draft=Path('/draft'),sequence_counts=[1,4])
engine=eval(compile(ast.Expression(node.value),'<engine_args>','eval'),{'str':str,'max':max,'PREFILL_BACKEND':PREFILL_BACKEND},{'args':args})
assert engine['attention_backend']=='FLASHINFER_MLA'
assert engine['speculative_config']['attention_backend']=='FLASHINFER_MLA'
assert engine['attention_config']=={'use_prefill_query_quantization':True,'mla_prefill_backend':'TRTLLM_RAGGED'}
subprocess.run([sys.executable,'-m','collector.vllm.collect_kimi_native','--help'],check=True)
receipt={'status':'passed','scope':'CPU import/CLI and all nine exact image source hashes; no GPU kernel execution','engine_args':engine,'source_sha256':manifest,'bundle_sha256':{str(p.relative_to(bundle)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (bundle/'collector/vllm').glob('*') if p.is_file()}}
out=Path('/workspace/results/dspark-e2e-20261014/kimi-native-ragged-preflight.json');out.write_text(json.dumps(receipt,indent=2)+'\n')
PY
