#!/usr/bin/env bash
set -euo pipefail
: "${storage_root:?}"
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
srun --nodes=1 --ntasks=1 --gres=gpu:0 --cpus-per-task=2 --mem=8G \
 --container-image="$storage_root/images/vllm-ac9126e58aa7-3d17635c.sqsh" \
 --container-mounts="$storage_root:/workspace,/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model:/scratch/fsw/portfolios/coreai/projects/coreai_dlalgo_ci/artifacts/model:ro" \
 --container-env=OMP_NUM_THREADS,MKL_NUM_THREADS python3 - <<'PY'
import hashlib,json,sys
from pathlib import Path
import torch,vllm
from vllm.platforms.interface import DeviceCapability
from vllm.v1.attention.backends.mla.prefill.selector import MLAPrefillSelectorConfig
from vllm.v1.attention.backends.mla.prefill.base import MLADimensions
from vllm.v1.attention.backends.mla.prefill.trtllm_ragged import TrtllmRaggedPrefillBackend
from vllm.config.attention import AttentionConfig
root=Path(vllm.__file__).parent
out=Path('/workspace/results/dspark-e2e-20261014/kimi-ragged-preflight');out.mkdir(exist_ok=True)
source={}
files=list((root/'v1/attention/backends/mla/prefill').glob('*.py'))+[root/'config/attention.py',root/'model_executor/layers/attention/mla_attention.py']
for p in files:
 relative=p.relative_to(root); dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());source[str(relative)]=hashlib.sha256(p.read_bytes()).hexdigest()
config=AttentionConfig(backend='FLASHINFER_MLA',mla_prefill_backend='TRTLLM_RAGGED',use_prefill_query_quantization=True)
selector=MLAPrefillSelectorConfig(dtype=torch.bfloat16,mla_dimensions=MLADimensions(qk_nope_head_dim=128,qk_rope_head_dim=64,v_head_dim=128))
reasons=TrtllmRaggedPrefillBackend.validate_configuration(DeviceCapability(10,3),selector)
available=TrtllmRaggedPrefillBackend.is_available()
receipt={'status':'passed' if not reasons and available else 'failed','scope':'CPU source/import/config validation for declared B300 capability10.3; no GPU kernel execution','attention_config':{'backend':str(config.backend),'mla_prefill_backend':str(config.mla_prefill_backend),'use_prefill_query_quantization':config.use_prefill_query_quantization},'backend_available':available,'validation_reasons':reasons,'source_sha256':source}
bundle=Path('/workspace/jobs/dspark-e2e-20261014/kimi-ragged-serving-bundle')
sys.path.insert(0,str(bundle))
from serve_smoke import server_command
command,env,checkpoint=server_command('kimi-k3',2,8010,synthetic_al=2.51,graph_policy='runtime-default',load_strategy='eager',startup_timeout_s=6000)
assert json.loads(command[command.index('--attention-config')+1])['mla_prefill_backend']=='TRTLLM_RAGGED'
receipt.update(server_command=command,checkpoint=checkpoint,bundle_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in bundle.iterdir() if p.is_file()})
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
assert not reasons and available
PY
